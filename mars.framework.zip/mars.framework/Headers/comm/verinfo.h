
#ifndef Mars_verinfo_h
#define Mars_verinfo_h

#define MARS_REVISION "4df0d6c6"
#define MARS_PATH "master"
#define MARS_URL ""
#define MARS_BUILD_TIME "2019-09-10 14:42:03"
#define MARS_TAG ""

#endif
